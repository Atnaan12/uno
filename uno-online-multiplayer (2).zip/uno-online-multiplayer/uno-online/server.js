'use strict';
const path = require('path');
const http = require('http');
const express = require('express');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: true }, pingInterval: 25000, pingTimeout: 20000 });
const PORT = process.env.PORT || 3000;
const rooms = new Map();
app.use(express.static(path.join(__dirname, 'public')));
app.get('/health', (_req, res) => res.json({ ok: true, rooms: rooms.size }));

const COLORS = ['red', 'blue', 'green', 'yellow'];
const COLOR_EMOJI = { red: '🔴', blue: '🔵', green: '🟢', yellow: '🟡' };
const makeId = () => Math.random().toString(36).slice(2, 10);
const roomCode = () => Math.random().toString(36).slice(2, 6).toUpperCase();
const safeName = value => String(value || '').trim().replace(/[<>]/g, '').slice(0, 18) || 'Player';
const shuffle = arr => { for (let i = arr.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [arr[i], arr[j]] = [arr[j], arr[i]]; } return arr; };

function createDeck() {
  const deck = [];
  for (const color of COLORS) {
    deck.push({ id: makeId(), color, value: '0' });
    for (let n = 1; n <= 9; n++) { deck.push({ id: makeId(), color, value: String(n) }, { id: makeId(), color, value: String(n) }); }
    for (const value of ['skip', 'reverse', 'draw2']) for (let i = 0; i < 2; i++) deck.push({ id: makeId(), color, value });
  }
  for (let i = 0; i < 4; i++) deck.push({ id: makeId(), color: 'wild', value: 'wild' }, { id: makeId(), color: 'wild', value: 'wild4' });
  return shuffle(deck);
}
function refillDeck(game) {
  if (game.deck.length) return;
  if (game.discard.length <= 1) return;
  const top = game.discard.pop();
  game.deck = shuffle(game.discard.splice(0));
  game.discard = [top];
}
function drawCards(game, player, count) {
  for (let i = 0; i < count; i++) { refillDeck(game); if (!game.deck.length) break; player.hand.push(game.deck.pop()); }
}
function currentTop(game) { return game.discard[game.discard.length - 1]; }
function canPlay(card, game) {
  const top = currentTop(game);
  return card.color === 'wild' || card.color === game.activeColor || card.value === top.value;
}
function playerIndex(game, socketId) { return game.players.findIndex(p => p.id === socketId); }
function nextIndex(game, from = game.turn, step = 1) { return (from + step + game.players.length) % game.players.length; }
function roomForSocket(socketId) {
  for (const room of rooms.values()) if (room.players.some(p => p.id === socketId)) return room;
  return null;
}
function sendError(socket, message) { socket.emit('notice', { type: 'error', message }); }
function publicState(room, viewerId) {
  const g = room.game;
  const me = room.players.find(p => p.id === viewerId);
  return {
    code: room.code, hostId: room.hostId, status: room.status,
    players: room.players.map((p, i) => ({ id: p.id, name: p.name, count: p.hand.length, isHost: p.id === room.hostId, isTurn: !!g && i === g.turn, saidUno: p.saidUno })),
    me: me ? { id: me.id, name: me.name, hand: me.hand } : null,
    game: g ? { top: currentTop(g), activeColor: g.activeColor, turnId: room.players[g.turn]?.id || null, direction: g.direction, deckCount: g.deck.length, discardCount: g.discard.length, hasDrawn: g.drawnCardId !== null, drawnCardId: g.turn === room.players.findIndex(p => p.id === viewerId) ? g.drawnCardId : null, winnerId: g.winnerId, message: g.message } : null
  };
}
function broadcastRoom(room) { for (const p of room.players) io.to(p.id).emit('state', publicState(room, p.id)); }
function advanceTurn(game, steps = 1) { game.turn = nextIndex(game, game.turn, game.direction * steps); game.drawnCardId = null; }
function startGame(room) {
  const deck = createDeck();
  room.players.forEach(p => { p.hand = []; p.saidUno = false; });
  const game = { deck, discard: [], activeColor: 'red', turn: 0, direction: 1, drawnCardId: null, winnerId: null, message: 'Game started! Match the color or number.', pendingUno: null };
  room.players.forEach(p => drawCards(game, p, 7));
  let first = game.deck.pop();
  while (first && first.color === 'wild') { game.deck.unshift(first); first = game.deck.pop(); }
  if (!first) first = { id: makeId(), color: 'red', value: '0' };
  game.discard.push(first); game.activeColor = first.color;
  if (first.value === 'skip') game.turn = 1 % room.players.length;
  if (first.value === 'draw2') { drawCards(game, room.players[game.turn], 2); game.turn = nextIndex(game, game.turn); }
  if (first.value === 'reverse' && room.players.length > 2) game.direction = -1;
  room.game = game; room.status = 'playing';
}
function removeRoomIfEmpty(room) { if (!room.players.length) rooms.delete(room.code); }

io.on('connection', socket => {
  socket.on('create-room', ({ name } = {}) => {
    if (roomForSocket(socket.id)) return sendError(socket, 'Waxaad hore ugu jirtaa room. Ka bax marka hore.');
    let code; do { code = roomCode(); } while (rooms.has(code));
    const player = { id: socket.id, name: safeName(name), hand: [], saidUno: false };
    const room = { code, hostId: socket.id, players: [player], status: 'waiting', game: null };
    rooms.set(code, room); socket.join(code); socket.emit('joined', { code }); broadcastRoom(room);
  });
  socket.on('join-room', ({ code, name } = {}) => {
    if (roomForSocket(socket.id)) return sendError(socket, 'Waxaad hore ugu jirtaa room. Ka bax marka hore.');
    code = String(code || '').trim().toUpperCase();
    const room = rooms.get(code);
    if (!room) return sendError(socket, 'Room code lama helin. Hubi code-ka.');
    if (room.status !== 'waiting') return sendError(socket, 'Ciyaartu way bilaabatay; room-kan lama geli karo hadda.');
    if (room.players.length >= 6) return sendError(socket, 'Room-ku waa buuxaa (ugu badnaan 6 ciyaartoy).');
    room.players.push({ id: socket.id, name: safeName(name), hand: [], saidUno: false });
    socket.join(code); socket.emit('joined', { code }); broadcastRoom(room);
  });
  socket.on('start-game', () => {
    const room = roomForSocket(socket.id);
    if (!room) return sendError(socket, 'Marka hore room gal.');
    if (room.hostId !== socket.id) return sendError(socket, 'Host-ka oo keliya ayaa bilaabi kara ciyaarta.');
    if (room.status !== 'waiting') return sendError(socket, 'Ciyaartu mar hore ayay u bilaabatay.');
    if (room.players.length < 2) return sendError(socket, 'Ugu yaraan 2 ciyaartoy ayaa loo baahan yahay.');
    startGame(room); broadcastRoom(room);
  });
  socket.on('play-card', ({ cardId, color } = {}) => {
    const room = roomForSocket(socket.id); if (!room || room.status !== 'playing' || !room.game) return sendError(socket, 'Ciyaar socota ma jirto.');
    const g = room.game, idx = playerIndex(g, socket.id), p = room.players[idx];
    if (idx !== g.turn) return sendError(socket, 'Ma aha turn-kaaga.');
    const handIndex = p.hand.findIndex(c => c.id === cardId); if (handIndex < 0) return sendError(socket, 'Kaarkaas gacantaada kuma jiro.');
    const card = p.hand[handIndex];
    if (g.drawnCardId && card.id !== g.drawnCardId) return sendError(socket, 'Markaad kaar qaadato, kaliya kaarkaas ayaad ciyaari kartaa ama turn-ka dhaafi kartaa.');
    if (!canPlay(card, g)) return sendError(socket, 'Kaar ma aha mid la ciyaari karo: midab ama number/action isma waafaqaan.');
    if (card.value === 'wild4' && p.hand.some(c => c.color === g.activeColor)) return sendError(socket, '+4 lama ciyaari karo haddii aad haysato kaar la midab ah.');
    if (card.color === 'wild' && !COLORS.includes(color)) return sendError(socket, 'Dooro midab sax ah kaarka Wild.');
    p.hand.splice(handIndex, 1); g.discard.push(card); g.activeColor = card.color === 'wild' ? color : card.color;
    p.saidUno = false; g.drawnCardId = null;
    if (p.hand.length === 1) g.pendingUno = p.id; else g.pendingUno = null;
    if (p.hand.length === 0) { g.winnerId = p.id; room.status = 'finished'; g.message = `${p.name} ayaa guuleystay!`; broadcastRoom(room); return; }
    if (card.value === 'reverse') { g.direction *= -1; if (room.players.length === 2) advanceTurn(g, 2); else advanceTurn(g); }
    else if (card.value === 'skip') advanceTurn(g, 2);
    else if (card.value === 'draw2') { const target = room.players[nextIndex(g)]; drawCards(g, target, 2); advanceTurn(g, 2); }
    else if (card.value === 'wild4') { const target = room.players[nextIndex(g)]; drawCards(g, target, 4); advanceTurn(g, 2); }
    else advanceTurn(g);
    g.message = `${p.name} wuxuu ciyaaray ${card.color === 'wild' ? card.value : `${card.color} ${card.value}`}.`;
    broadcastRoom(room);
  });
  socket.on('draw-card', () => {
    const room = roomForSocket(socket.id); if (!room || room.status !== 'playing' || !room.game) return sendError(socket, 'Ciyaar socota ma jirto.');
    const g = room.game, idx = playerIndex(room, socket.id), p = room.players[idx];
    if (idx !== g.turn) return sendError(socket, 'Ma aha turn-kaaga.');
    if (g.drawnCardId) return sendError(socket, 'Waxaad hore u qaadatay kaar. Ciyaar kaarkaas ama dhaaf turn-ka.');
    const before = p.hand.length; drawCards(g, p, 1);
    if (p.hand.length === before) { g.message = 'Deck-ku wuu dhammaaday.'; advanceTurn(g); }
    else { g.drawnCardId = p.hand[p.hand.length - 1].id; g.message = `${p.name} wuxuu qaatay hal kaar.`; }
    broadcastRoom(room);
  });
  socket.on('pass-turn', () => {
    const room = roomForSocket(socket.id); if (!room || room.status !== 'playing' || !room.game) return sendError(socket, 'Ciyaar socota ma jirto.');
    const g = room.game, idx = playerIndex(room, socket.id);
    if (idx !== g.turn) return sendError(socket, 'Ma aha turn-kaaga.');
    if (!g.drawnCardId) return sendError(socket, 'Marka hore qaado kaar haddii aadan haysan mid la ciyaari karo.');
    advanceTurn(g); g.message = `${room.players[idx].name} wuxuu dhaafay turn-ka.`; broadcastRoom(room);
  });
  socket.on('say-uno', () => {
    const room = roomForSocket(socket.id); if (!room || !room.game) return;
    const p = room.players.find(p => p.id === socket.id); if (p && p.hand.length === 1) { p.saidUno = true; room.game.pendingUno = null; room.game.message = `${p.name} wuxuu yiri UNO!`; broadcastRoom(room); }
    else sendError(socket, 'UNO waxaa la dhahaa marka hal kaar kuu haro.');
  });
  socket.on('leave-room', () => {
    const room = roomForSocket(socket.id); if (!room) return;
    const leaving = room.players.find(p => p.id === socket.id); room.players = room.players.filter(p => p.id !== socket.id); socket.leave(room.code);
    if (!room.players.length) { rooms.delete(room.code); return; }
    if (room.hostId === socket.id) room.hostId = room.players[0].id;
    if (room.game && room.status === 'playing') {
      const oldTurn = room.game.turn;
      const removedIdx = oldTurn; // Recalculate current turn by keeping a valid index.
      if (removedIdx >= room.players.length) room.game.turn = 0;
      if (room.players.length < 2) { room.status = 'waiting'; room.game = null; }
    }
    if (leaving) io.to(room.code).emit('notice', { type: 'info', message: `${leaving.name} wuxuu ka baxay room-ka.` });
    broadcastRoom(room); removeRoomIfEmpty(room);
  });
  socket.on('disconnect', () => {
    const room = roomForSocket(socket.id); if (!room) return;
    const leaving = room.players.find(p => p.id === socket.id); const oldIndex = playerIndex(room, socket.id);
    room.players = room.players.filter(p => p.id !== socket.id);
    if (!room.players.length) { rooms.delete(room.code); return; }
    if (room.hostId === socket.id) room.hostId = room.players[0].id;
    if (room.game) {
      if (oldIndex < room.game.turn) room.game.turn--;
      if (room.game.turn >= room.players.length) room.game.turn = 0;
      if (room.players.length < 2) { room.status = 'waiting'; room.game = null; }
    }
    if (leaving) io.to(room.code).emit('notice', { type: 'info', message: `${leaving.name} wuu go'ay.` });
    broadcastRoom(room); removeRoomIfEmpty(room);
  });
});
server.listen(PORT, '0.0.0.0', () => console.log(`UNO server running on port ${PORT}`));
