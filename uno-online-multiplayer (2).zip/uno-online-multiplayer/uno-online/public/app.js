'use strict';
const socket = io();
const $ = id => document.getElementById(id);
let state = null, currentRoom = null, pendingWildCard = null, noticeTimer = null;
const COLORS = ['red', 'blue', 'green', 'yellow'];
const COLOR_NAMES = { red: 'RED', blue: 'BLUE', green: 'GREEN', yellow: 'YELLOW' };
const VALUE_LABELS = { skip: '⊘', reverse: '↻', draw2: '+2', wild: 'WILD', wild4: '+4' };
function showNotice(message, type = 'info') {
  const el = $('notice'); el.textContent = message; el.className = `notice ${type}`;
  clearTimeout(noticeTimer); noticeTimer = setTimeout(() => el.classList.add('hidden'), 4200);
}
function setConnected(ok) { $('connectionDot').parentElement.classList.toggle('online', ok); $('connectionText').textContent = ok ? 'Connected' : 'Reconnecting…'; }
socket.on('connect', () => setConnected(true)); socket.on('disconnect', () => setConnected(false));
socket.on('notice', n => showNotice(n.message, n.type || 'info'));
socket.on('joined', ({ code }) => { currentRoom = code; $('lobbyScreen').classList.add('hidden'); $('roomScreen').classList.remove('hidden'); $('roomCodeLabel').textContent = code; });
socket.on('state', next => { state = next; render(); });
function getName() { return $('playerName').value.trim() || 'Player'; }
$('createBtn').addEventListener('click', () => socket.emit('create-room', { name: getName() }));
$('joinBtn').addEventListener('click', () => { const code = $('roomCode').value.trim().toUpperCase(); if (code.length !== 4) return showNotice('Geli room code ka 4 xaraf ah.', 'error'); socket.emit('join-room', { code, name: getName() }); });
$('roomCode').addEventListener('input', e => { e.target.value = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 4); });
$('playerName').addEventListener('keydown', e => { if (e.key === 'Enter') $('createBtn').click(); });
$('roomCode').addEventListener('keydown', e => { if (e.key === 'Enter') $('joinBtn').click(); });
$('copyCodeBtn').addEventListener('click', async () => { try { await navigator.clipboard.writeText(currentRoom); showNotice(`Room code ${currentRoom} waa la copy-gareeyay.`); } catch { showNotice(`Room code-kaagu waa ${currentRoom}. Copy-garee gacanta.`); } });
$('startBtn').addEventListener('click', () => socket.emit('start-game'));
function leaveRoom() { socket.emit('leave-room'); currentRoom = null; state = null; pendingWildCard = null; $('roomScreen').classList.add('hidden'); $('lobbyScreen').classList.remove('hidden'); $('waitingPanel').classList.remove('hidden'); $('gamePanel').classList.add('hidden'); $('modalBackdrop').classList.add('hidden'); }
$('leaveWaitingBtn').addEventListener('click', leaveRoom); $('leaveGameBtn').addEventListener('click', leaveRoom); $('backToLobbyBtn').addEventListener('click', leaveRoom);
$('drawBtn').addEventListener('click', () => socket.emit('draw-card')); $('passBtn').addEventListener('click', () => socket.emit('pass-turn')); $('unoBtn').addEventListener('click', () => socket.emit('say-uno'));
document.querySelectorAll('.color-choice').forEach(btn => btn.addEventListener('click', () => { if (pendingWildCard) { socket.emit('play-card', { cardId: pendingWildCard, color: btn.dataset.color }); pendingWildCard = null; $('colorPicker').classList.add('hidden'); } }));
function render() {
  if (!state) return;
  $('roomCodeLabel').textContent = state.code; $('playerCount').textContent = `${state.players.length}/6`;
  const isHost = state.hostId === socket.id;
  $('startBtn').disabled = !isHost || state.players.length < 2 || state.status !== 'waiting';
  $('startBtn').style.opacity = $('startBtn').disabled ? '.45' : '1';
  $('startBtn').textContent = state.status === 'waiting' ? (isHost ? 'Start game  →' : 'Waiting for host…') : 'Game started';
  $('waitingPlayers').innerHTML = state.players.map((p, i) => `<div class="player-tile"><div class="avatar">${escapeHtml(p.name.charAt(0).toUpperCase())}</div><div><strong>${escapeHtml(p.name)} ${p.id === socket.id ? '(You)' : ''}</strong><small>${p.isHost ? '♛ Host' : `Player ${i + 1}`}</small></div></div>`).join('');
  if (state.status === 'waiting') { $('waitingPanel').classList.remove('hidden'); $('leaveWaitingBtn').classList.remove('hidden'); $('gamePanel').classList.add('hidden'); $('roomSubtext').textContent = 'Waiting for friends to join…'; $('modalBackdrop').classList.add('hidden'); return; }
  $('waitingPanel').classList.add('hidden'); $('leaveWaitingBtn').classList.add('hidden'); $('gamePanel').classList.remove('hidden');
  if (!state.game) return;
  const g = state.game, me = state.me, myTurn = g.turnId === socket.id;
  $('roomSubtext').textContent = state.status === 'finished' ? 'Game finished' : 'Game in progress';
  $('turnPill').textContent = state.status === 'finished' ? 'Game over' : (myTurn ? 'YOUR TURN' : `Turn: ${state.players.find(p => p.id === g.turnId)?.name || 'Player'}`);
  $('deckCount').textContent = g.deckCount; $('activeColorLabel').textContent = COLOR_NAMES[g.activeColor] || g.activeColor;
  renderTopCard(g.top); renderOpponents(state.players.filter(p => p.id !== socket.id)); renderHand(me.hand, myTurn, g);
  $('gameMessage').textContent = g.message || 'Your move.';
  $('drawBtn').disabled = !myTurn || g.hasDrawn || state.status !== 'playing'; $('drawBtn').style.opacity = $('drawBtn').disabled ? '.55' : '1';
  $('passBtn').disabled = !myTurn || !g.hasDrawn || state.status !== 'playing'; $('passBtn').style.opacity = $('passBtn').disabled ? '.45' : '1';
  $('unoBtn').style.opacity = me.hand.length === 1 ? '1' : '.45';
  if (state.status === 'finished' && g.winnerId) { const winner = state.players.find(p => p.id === g.winnerId); $('modalTitle').textContent = `${winner?.name || 'Player'} wins!`; $('modalText').textContent = winner?.id === socket.id ? 'Amazing! You emptied your hand first.' : `${winner?.name || 'A player'} emptied their hand first. Rematch by creating a new room.`; $('modalBackdrop').classList.remove('hidden'); } else $('modalBackdrop').classList.add('hidden');
}
function escapeHtml(str) { return String(str).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function valueLabel(value) { return VALUE_LABELS[value] || value; }
function cardClass(card) { return card.color === 'wild' ? 'card-wild' : `card-${card.color}`; }
function renderTopCard(card) { const el = $('topCard'); el.className = `card ${cardClass(card)}`; const label = valueLabel(card.value); el.innerHTML = `<span class="card-value ${label.length > 2 ? 'word' : ''}">${label}</span><span class="card-corner top">${label}</span><span class="card-corner bottom">${label}</span>`; }
function renderOpponents(players) { $('opponents').innerHTML = players.map(p => `<div class="opponent ${p.isTurn ? 'active' : ''}"><div class="avatar">${escapeHtml(p.name.charAt(0).toUpperCase())}</div><div><strong>${escapeHtml(p.name)}</strong><small>${p.isTurn ? 'Playing now' : `${p.count} cards`}</small></div><div class="mini-cards">${Array.from({length:Math.min(p.count, 3)}, () => '<span class="mini-card"></span>').join('')}</div></div>`).join(''); }
function renderHand(hand, myTurn, game) {
  $('handCount').textContent = hand.length;
  $('hand').innerHTML = hand.map(card => {
    const label = valueLabel(card.value); const canMatch = card.color === 'wild' || card.color === game.activeColor || card.value === game.top.value;
    const disabled = !myTurn || (game.hasDrawn && card.id !== game.drawnCardId);
    return `<button class="card ${cardClass(card)} ${disabled ? 'disabled' : ''}" data-card-id="${card.id}" aria-label="${escapeHtml(card.color)} ${escapeHtml(card.value)}"><span class="card-value ${label.length > 2 ? 'word' : ''}">${label}</span><span class="card-corner top">${label}</span><span class="card-corner bottom">${label}</span></button>`;
  }).join('');
  $('hand').querySelectorAll('[data-card-id]').forEach(btn => btn.addEventListener('click', () => {
    if (!myTurn || game.winnerId) return;
    const card = hand.find(c => c.id === btn.dataset.cardId); if (!card) return;
    if (card.color === 'wild') { pendingWildCard = card.id; $('colorPicker').classList.remove('hidden'); $('gameMessage').textContent = 'Choose the color for your Wild card.'; return; }
    $('colorPicker').classList.add('hidden'); socket.emit('play-card', { cardId: card.id });
  }));
}
