# UNO Online Multiplayer

A real-time browser card game for 2–6 players, built with HTML, CSS, vanilla JavaScript, Node.js, Express and Socket.IO. The server owns the room state, hands, turns, draw pile, discard pile and move validation.

## Features

- Create private rooms with a four-character code; join from another device/browser.
- 2–6 players per room; the room host starts the game.
- UNO-style 108-card deck: number cards, Skip, Reverse, Draw Two, Wild and Wild Draw Four.
- Server-side turn enforcement, card ownership checks, matching-color/value checks, Wild color validation, and Wild Draw Four restriction when a matching-color card is held.
- Player hands are only sent to that player; opponents see card counts, not card faces.
- Responsive UI for desktop and mobile; health endpoint at `/health`.

## Requirements

- Node.js 18 or newer
- npm

## Run locally

1. Extract the ZIP.
2. Open a terminal inside the `uno-online` folder.
3. Install dependencies:

   ```bash
   npm install
   ```

4. Start the server:

   ```bash
   npm start
   ```

5. Open `http://localhost:3000` in your browser. To test multiplayer locally, open another browser or an incognito window and join using the room code.

## Free deployment on Render

This project uses a persistent Node.js process and Socket.IO, so deploy it as a **Web Service**, not as a static site.

1. Create a GitHub repository and upload all files from this folder.
2. Sign in to Render and select **New → Web Service**.
3. Connect your repository.
4. Set:
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Runtime:** Node
5. Choose the Free instance plan and deploy.
6. Open the generated `https://your-service.onrender.com` URL and share it with friends.

Render's free services can sleep after inactivity, and the first request after sleeping can take around a minute. Restarts or deployments can disconnect active rooms because room state is stored in memory. This is suitable for casual play/testing, not persistent competitive games. For production, add persistent/shared room storage and reconnect recovery.

## Rules / implementation notes

- A playable card matches the current active color, matches the top card's value/action, or is a Wild card.
- Wild cards require the player to choose a color.
- Wild Draw Four is rejected if the player holds a card matching the current active color. The target player draws four and loses their turn.
- Draw Two makes the next player draw two and lose their turn.
- Skip skips the next player. Reverse reverses direction; with two players it behaves as a skip.
- A player wins by playing their last card.
- Players should press **UNO!** when they have one card. This starter implementation announces UNO but does not implement a challenge/penalty window for forgetting to say UNO.

## Project structure

```text
uno-online/
├── package.json
├── server.js
├── README.md
├── render.yaml
└── public/
    ├── index.html
    ├── style.css
    └── app.js
```

## Important limitation

Rooms are held in server memory. If the service restarts or spins down, active rooms disappear. Also, this is a classic UNO-inspired implementation; house rules such as stacking Draw Twos, challenging Wild Draw Four, and a timed UNO penalty are not implemented.
